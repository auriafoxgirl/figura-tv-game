return {
   cable = {uv = vec(3, 9), itemOffset = vec(0, 10), depth = -1},
   ears = {uv = vec(8, 0), itemOffset = vec(0, 7), depth = 1, accessory = true},
   hat = {uv = vec(9, 0), itemOffset = vec(0, 8), depth = 0.5, accessory = true},
   ['long hair'] = {uv = vec(10, 0), itemOffset = vec(0, 0), depth = -1, accessory = true},
}