# Fix the tv static!
<img src="assets/image.png"></img>
Game for [Figura](https://github.com/figuraMC/Figura) avatar contest

# libraries
- [GNUI](https://github.com/lua-gods/GNUI)
